# Asset sources

## Hrefna raven

- Original: [Crow On Branch](https://www.clker.com/clipart-crow-on-branch.html)
- Shared by: jeneeford on Clker, November 13, 2011
- Source terms: [Clker Terms of Use](https://www.clker.com/disclaimer.html), which describe contributed clip art as public-domain or released under the latest CC0 public-domain dedication
- Local modifications: white background removed, transparent edges retained, artwork recolored copper for the Wondrous Places interface

